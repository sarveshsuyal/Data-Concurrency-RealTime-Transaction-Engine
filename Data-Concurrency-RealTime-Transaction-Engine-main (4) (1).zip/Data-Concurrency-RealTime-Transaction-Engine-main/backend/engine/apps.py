from django.apps import AppConfig

class EngineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'engine'
    verbose_name = 'DataCore Transaction & Concurrency Engine'
